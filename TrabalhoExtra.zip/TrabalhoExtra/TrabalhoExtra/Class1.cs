﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrabalhoExtra
{
    public class Pedido
    {
        public int Id { get; set; }
        public DateTime DataPedido { get; set; }
        public List<ItemPedido> Itens { get; set; }

        public Pedido()
        {
            DataPedido = DateTime.Now;
            Itens = new List<ItemPedido>();
        }

        public void AdicionarItem(ItemPedido item)
        {
            Itens.Add(item);
        }

        public decimal CalcularTotal()
        {
            decimal total = 0;
            foreach (var item in Itens)
            {
                total += item.CalcularSubtotal();
            }
            return total;
        }
    }

    public class ItemPedido
    {
        public int IdItem { get; set; }
        public string Nome { get; set; }
        public decimal Preco { get; set; }
        public int Quantidade { get; set; }

        public decimal CalcularSubtotal()
        {
            return Preco * Quantidade;
        }
    }

}
