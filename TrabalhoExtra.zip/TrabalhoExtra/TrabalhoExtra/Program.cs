﻿using TrabalhoExtra;

ItemPedido item1 = new ItemPedido { IdItem = 1, Nome = "Pizza", Preco = 29.99m, Quantidade = 1 };
ItemPedido item2 = new ItemPedido { IdItem = 2, Nome = "Refrigerante", Preco = 5.50m, Quantidade = 2 };

Pedido pedido = new Pedido();
pedido.AdicionarItem(item1);
pedido.AdicionarItem(item2);

Console.WriteLine($"Itens do pedido feito em {pedido.DataPedido}:");
foreach (var item in pedido.Itens)
{
    Console.WriteLine($"{item.Nome} - {item.Preco:C2} x {item.Quantidade} = {item.CalcularSubtotal():C2}");
}

Console.WriteLine($"Total do pedido: {pedido.CalcularTotal():C2}");