using TrabalhoExtra;

namespace TestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestarAdicionarItemETotalPedido()
        {
            ItemPedido item1 = new ItemPedido { IdItem = 1, Nome = "Hamb�rguer", Preco = 15.99m, Quantidade = 2 };
            ItemPedido item2 = new ItemPedido { IdItem = 2, Nome = "Batata Frita", Preco = 8.50m, Quantidade = 1 };

            Pedido pedido = new Pedido();
            pedido.AdicionarItem(item1);
            pedido.AdicionarItem(item2);

            decimal totalEsperado = item1.CalcularSubtotal() + item2.CalcularSubtotal();
            Assert.AreEqual(totalEsperado, pedido.CalcularTotal());
        }
    }
}